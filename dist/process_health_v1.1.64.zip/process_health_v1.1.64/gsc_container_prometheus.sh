#!/usr/bin/env bash
#
# Compatibility wrapper (legacy name)
#
# This script is kept for backward compatibility.
# Use: gsc_prometheus.sh
#
set -euo pipefail
IFS=$'\n\t'

_here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${_here}/gsc_prometheus.sh" "$@"
