#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Script: gsc_grafana.sh
# Description: Sets up a Grafana container with specified dashboards using Docker or Podman.
#              Supports dashboard files, URLs, git repositories, and compressed archives.
# Author: GSC
# -----------------------------------------------------------------------------

_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "${_script_dir}/gsc_core.sh"

# -------------------------------
# Configuration and defaults
# -------------------------------
_container_engine=""
_dashboards=()
_url=""
_git_repo=""
_datasource_url="http://prometheus:9090"
_grafana_port="3000"
_admin_password="admin"
_update_dashboards=0
_query_mode=0
_cleanup_mode=0
_cleanup_volumes=0
_override_confirm=""
_script_name=$(basename "$0")
_dashboard_dir="dashboards"
_provisioning_dir="provisioning"
_customer="unknown"
_sr_number="unknown"
_timestamp=$(date +%Y%m%d_%H%M%S)
_error_log="${_timestamp}.error.log"

# -------------------------------
# Helper: Print usage
# -------------------------------
print_usage() {
    cat <<EOF
Usage: $_script_name [-p|--podman] [-d|--docker] -D|--dashboard [file2 ...] [options]

Core Options:
  -p, --podman                       Use Podman as the container engine
  -d, --docker                       Use Docker as the container engine
  -D, --dashboard FILE               Add one or more dashboard JSON or archive files
  -f FILE                            Alias for -D (for compatibility with healthcheck suite)
  -c, --customer NAME                Specify the customer name (for organizational purposes)
  -s, --sr-number SR_NUMBER          Specify the Service Request (SR) number
  --url URL                          Download dashboard archive or JSON from URL
  --git URL                          Clone a Git repository containing dashboard JSON files

Additional Options:
  -i, --input IP:PORT,
  --prometheus-data-source IP:PORT   Specify the Prometheus datasource IP and port (e.g., 172.22.20.26:9090)
  -g, --grafana-port PORT            Specify the Grafana port (default: 3000)
  --admin-password PASSWORD          Specify the Grafana admin password (default: admin)
  --update                           Update existing dashboards without clearing the directory
  --query                            Scan for running Prometheus containers and healthcheck.conf to set the datasource
  --cleanup                          Stop and remove the Grafana container
  --volume                           Delete dashboards and provisioning directories during cleanup (requires --cleanup)
  --override=y                       Skip confirmation prompts for cleanup
  
  Example:
    sudo $_script_name --docker -D dashboard1.json dashboards.zip
    sudo $_script_name --podman --prometheus-data-source 172.22.20.26:9090 --grafana-port 3001 --update
    sudo $_script_name --podman --query
EOF
    exit 1
}
  
# -------------------------------
# Helper: Query Prometheus Sources
# -------------------------------
query_prometheus_sources() {
    local -a _found_sources=()
    local _hc_file="healthcheck.conf"

    gsc_log_info "Scanning for Prometheus data sources..."

    # Check healthcheck.conf
    if [[ -f "$_hc_file" ]]; then
        local _hc_port
        _hc_port=$(grep -E "^_prom_port=" "$_hc_file" | cut -d'"' -f2)
        if [[ -n "$_hc_port" ]]; then
            _found_sources+=("healthcheck.conf (Port: $_hc_port)")
        fi
    fi

    # Scan running containers (try both podman and docker)
    local _runtime
    for _runtime in podman docker; do
        if command -v "$_runtime" >/dev/null 2>&1; then
            local _container_info
            _container_info=$("$_runtime" ps --format '{{.Names}} {{.Ports}}' 2>/dev/null | grep "9090" || true)

            while IFS= read -r _line; do
                [[ -z "$_line" ]] && continue
                local _name="${_line%% *}"
                local _ports="${_line#* }"
                local _hp
                # Extract host port from mapping (e.g., 0.0.0.0:9090->9090/tcp or 9090/tcp)
                if [[ "$_ports" =~ :([0-9]+)-\>9090 ]]; then
                    _hp="${BASH_REMATCH[1]}"
                    _found_sources+=("Container: $_name (Port: $_hp)")
                fi
            done <<< "$_container_info"
        fi
    done

    if [[ ${#_found_sources[@]} -eq 0 ]]; then
        gsc_log_warn "No Prometheus sources found in containers or healthcheck.conf."
        return 0
    fi

    gsc_log_info "Found Prometheus sources:"
    for i in "${!_found_sources[@]}"; do
        printf "  [%d] %s\n" "$i" "${_found_sources[$i]}"
    done

    local _choice
    read -rp "Select a source [0-$((${#_found_sources[@]}-1))]: " _choice
    if [[ ! "$_choice" =~ ^[0-9]+$ ]] || [[ "$_choice" -lt 0 ]] || [[ "$_choice" -ge ${#_found_sources[@]} ]]; then
        gsc_log_warn "Invalid selection. Using default data source."
        return 0
    fi

    local _selected_port
    _selected_port=$(echo "${_found_sources[$_choice]}" | grep -oE "Port: [0-9]+" | cut -d' ' -f2)

    local _selected_ip
    read -rp "Enter Prometheus IP address [default: 127.0.0.1]: " _selected_ip
    _selected_ip=${_selected_ip:-127.0.0.1}

    _datasource_url="http://$_selected_ip:$_selected_port"
    gsc_log_ok "Datasource set to: $_datasource_url"
}

# -------------------------------
# Helper: Cleanup Grafana
# -------------------------------
cleanup_grafana() {
    local _runtime="${_container_engine:-}"
    if [[ -z "$_runtime" ]]; then
        if command -v podman >/dev/null 2>&1; then _runtime="podman"; else _runtime="docker"; fi
    fi
    gsc_container_cleanup "${_runtime}" "^grafana$" "${_override_confirm}" "${_cleanup_volumes}"
}

# -------------------------------
# Validate dashboard files
# -------------------------------
validate_dashboards() {
    for _file in "${_dashboards[@]}"; do
        [[ ! -f "$_file" ]] && gsc_log_error "Dashboard file not found: $_file" && exit 1
    done
}

# -------------------------------
# Extract supported archives
# -------------------------------
extract_archive() {
    local _archive="$1"
    mkdir -p "$_dashboard_dir"
    case "$_archive" in
        *.zip) unzip -o "$_archive" -d "$_dashboard_dir" ;;
        *.tar.gz) tar -xzf "$_archive" -C "$_dashboard_dir" ;;
        *.tar.xz) tar -xJf "$_archive" -C "$_dashboard_dir" ;;
        *) gsc_log_error "Unsupported archive format: $_archive"; exit 1 ;;
    esac
}

# -------------------------------
# Parse command-line arguments
# -------------------------------
parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -p|--podman) _container_engine="podman"; shift ;;
            -d|--docker) _container_engine="docker"; shift ;;
            -D|--dashboard|-f)
                shift
                while [[ $# -gt 0 && ! "$1" =~ ^- ]]; do
                    _dashboards+=("$1")
                    shift
                done
                ;;
            -c|--customer)
                shift
                _customer=$(gsc_sanitize_name "$1"); shift ;;
            -s|--sr-number)
                shift
                _sr_number=$(gsc_sanitize_name "$1"); shift ;;
            --url)
                shift
                _url="$1"; shift ;;
            --git)
                shift
                _git_repo="$1"; shift ;;
            -i|--input|--prometheus-data-source)
                shift
                _datasource_url="http://$1"; shift ;;
            -g|--grafana-port)
                shift
                _grafana_port="$1"; shift ;;
            --admin-password)
                shift
                _admin_password="$1"; shift ;;
            --update)
                _update_dashboards=1; shift ;;
            --query)
                _query_mode=1; shift ;;
            --cleanup)
                _cleanup_mode=1; shift ;;
            --volume)
                _cleanup_volumes=1; shift ;;
            --override=y)
                _override_confirm="y"; shift ;;
            -*) gsc_log_error "Unknown option: $1"; print_usage ;;
        esac
    done
}

# -------------------------------
# Download from URL if given
# -------------------------------
download_url() {
    if [[ -n "$_url" ]]; then
        gsc_log_info "Downloading from URL: $_url"
        mkdir -p temp_download
        curl -L -o temp_download/downloaded_file "$_url" || wget -O temp_download/downloaded_file "$_url"
        _dashboards+=("temp_download/downloaded_file")
    fi
}

# -------------------------------
# Clone Git repository if given
# -------------------------------
clone_git_repo() {
    if [[ -n "$_git_repo" ]]; then
        gsc_log_info "Cloning Git repo: $_git_repo"
        git clone "$_git_repo" temp_git || { gsc_log_error "Git clone failed."; exit 1; }
        local -a _repo_files=()
        mapfile -t _repo_files < <(find temp_git -type f -name '*.json')
        _dashboards+=("${_repo_files[@]}")
    fi
}

# -------------------------------
# Prepare file structure and provisioning
# -------------------------------
prepare_structure() {
    # Only create/clear dashboards directory if we are not in 'update' mode
    # or if we are in update mode but new dashboards were provided.
    if [[ "$_update_dashboards" -eq 0 ]]; then
        rm -rf "$_dashboard_dir"
        mkdir -p "$_dashboard_dir"
    fi

    mkdir -p "$_provisioning_dir/dashboards" "$_provisioning_dir/datasources"

    for _file in "${_dashboards[@]}"; do
        case "$_file" in
            *.json) cp "$_file" "$_dashboard_dir/" ;;
            *.zip|*.tar.gz|*.tar.xz) extract_archive "$_file" ;;
            *) gsc_log_error "Unsupported file type: $_file"; exit 1 ;;
        esac
    done

    cat > "$_provisioning_dir/dashboards/dashboards.yaml" <<EOF
apiVersion: 1
providers:
  - name: 'hcp-dashboards'
    orgId: 1
    folder: 'HCP Dashboards'
    type: file
    disableDeletion: false
    editable: true
    options:
      path: /var/lib/grafana/dashboards
EOF

    cat > "$_provisioning_dir/datasources/datasource.yaml" <<EOF
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: $_datasource_url
    isDefault: true
    editable: true
EOF

    cat > docker-compose.yaml <<EOF
version: '3'
services:
  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    ports:
      - "$_grafana_port:3000"
    volumes:
      - ./dashboards:/var/lib/grafana/dashboards
      - ./provisioning/dashboards:/etc/grafana/provisioning/dashboards
      - ./provisioning/datasources:/etc/grafana/provisioning/datasources
    environment:
      - GF_SECURITY_ADMIN_USER=admin
      - GF_SECURITY_ADMIN_PASSWORD=$_admin_password
EOF
}

# -------------------------------
# Launch Grafana
# -------------------------------
launch_grafana() {
    if [[ "$_container_engine" == "docker" ]]; then
        docker compose up -d 2>>"$_error_log"
        sleep 5
        if ! docker ps | grep -q grafana; then
            gsc_log_error "Docker failed to start Grafana. Cleaning up..."
            docker compose down 2>>"$_error_log"
            docker image rm grafana/grafana:latest 2>>"$_error_log"
            exit 1
        fi
    else
        podman run -d \
            --name=grafana \
            --replace \
            -p "$_grafana_port:3000" \
            -v "$(pwd)/dashboards:/var/lib/grafana/dashboards:Z" \
            -v "$(pwd)/provisioning/dashboards:/etc/grafana/provisioning/dashboards:Z" \
            -v "$(pwd)/provisioning/datasources:/etc/grafana/provisioning/datasources:Z" \
            -e GF_SECURITY_ADMIN_USER=admin \
            -e GF_SECURITY_ADMIN_PASSWORD="$_admin_password" \
            grafana/grafana:latest 2>>"$_error_log"
        sleep 5
        if ! podman ps | grep -q grafana; then
            gsc_log_error "Podman failed to start Grafana. Cleaning up..."
            podman rm -f grafana 2>>"$_error_log"
            podman image rm grafana/grafana:latest 2>>"$_error_log"
            exit 1
        fi
    fi
    gsc_log_ok "Grafana setup complete. Access it at http://localhost:$_grafana_port"
}


# -------------------------------
# Main
# -------------------------------
gsc_require_root
parse_args "$@"

if [[ "$_cleanup_mode" -eq 1 ]]; then
    cleanup_grafana
    exit 0
fi

[[ "$_query_mode" -eq 1 ]] && query_prometheus_sources
download_url
clone_git_repo
[[ -z "$_container_engine" ]] && gsc_log_error "Must specify --docker or --podman" && print_usage
if [[ $_update_dashboards -eq 0 && ${#_dashboards[@]} -eq 0 ]]; then
    gsc_log_error "At least one dashboard file must be specified with -D, --url, or --git (or use --update to use existing ones)"
    print_usage
fi
validate_dashboards
prepare_structure
launch_grafana
