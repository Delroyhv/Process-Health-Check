# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A health check and monitoring toolkit for **HCP Cloud Scale** (Hitachi Vantara) clusters. Processes support logs and Prometheus snapshots to surface errors, warnings, memory anomalies, and partition issues.

## Development Commands

```bash
make bash-n     # Syntax check all .sh files (bash -n)
make lint       # Run shellcheck on all .sh files
make bundle     # Create release tar.xz (also updates README version)
make docs       # Generate docs/ (Markdown + PDF) from man pages
```

To rebuild the `partition_growth` Go binary:
```bash
cd partition_growth && make all
```

## Architecture

### Entry Points

| Script | Role |
|--------|------|
| `gsc_healthcheck.sh` | End-to-end orchestrator: expands support bundle → starts Prometheus → runs `runchk.sh` |
| `runchk.sh` | Sequentially runs all `chk_*.sh` and `print_*.sh` checks, summarizes ERRORs/WARNINGs |
| `gsc_prometheus.sh` | Extracts a `psnap_*.tar.xz` and runs Prometheus in a Docker/Podman container |
| `gsc_grafana.sh` | Runs Grafana with provisioned HCP dashboards |
| `selfcheck.sh` | Validates all dependencies and required files (run at start of `runchk.sh`) |

### Shared Libraries

- **`gsc_core.sh`** — The single source of truth for all shared functions. All scripts source this. Contains: strict mode, logging (`gsc_log_*`), dependency checks (`gsc_require`), container engine abstraction, temp dir management, JSON helpers, partition artifact handling, and secure `sudo` vault management.
- **`gsc_library.sh`** — Thin compatibility shim that simply sources `gsc_core.sh`. Kept for backward compatibility.

**Rule:** All common/reusable functions must be placed in `gsc_core.sh`, not duplicated in individual scripts.

### Check Scripts (`chk_*.sh`)

Each check script focuses on one diagnostic area. They are invoked by `runchk.sh` in sequence:

- `chk_metrics.sh` — Queries Prometheus using definitions from `hcpcs_hourly_alerts.json` / `hcpcs_daily_alerts.json`
- `chk_services_memory.sh` — Validates service RSS memory against bounds in `memcheck.conf`
- `chk_collected_metrics.sh` — Validates quality of pre-collected metrics
- `chk_filesystem.sh`, `chk_disk_perf.sh`, `chk_partInfo.sh`, etc. — Filesystem/disk diagnostics
- `chk_cluster.sh`, `chk_snodes.sh` — Cluster state checks
- `chk_docker.sh`, `chk_chrony.sh`, `chk_top.sh`, `chk_messages.sh` — System-level checks

### Service Version Directories

`services_sh_25/` and `services_sh_26/` contain HCP software version-specific service scripts (v2.5 and v2.6). Scripts in these directories are sourced based on `_cs_version` from `healthcheck.conf`.

### Go Components

- **`partition_growth/main.go`** — Analyzes partition growth trends from JSON event data. Pre-compiled binaries in `partition_growth/build/` for linux/darwin × amd64/arm64. No Go files exist at the repo root.

### Configuration Files

- **`healthcheck.conf`** (generated, or use `healthcheck.conf.example`) — Prometheus connection params (`_prom_server`, `_prom_port`, `_cs_version`, etc.), sourced by `runchk.sh`
- **`memcheck.conf`** — Expected RSS memory bounds (min/max MB) per service name
- **`hcpcs_hourly_alerts.json`** / **`hcpcs_daily_alerts.json`** — Prometheus alert query definitions with warning/error thresholds (50+ metrics)
- **`os.conf`** — OS-level configuration

## Coding Conventions

- All scripts use `#!/usr/bin/env bash` and source `gsc_core.sh` for logging/utilities
- Logging: use `gsc_log_info`, `gsc_log_warn`, `gsc_log_error`, `gsc_log_ok`, `gsc_die`
- Important info → console (stderr via `gsc_log_*`); details → log files via `gsc_loga`
- Summary sections delimited with `++++++++++` separator lines
- Scripts that need root check with `gsc_require_root`; dependency checks use `gsc_require <cmd>...`
- Version tracked in `VERSION` file (e.g., `v1.2.52`); update it and its git tag on each release
- CI (GitHub Actions) runs `bash -n` and `shellcheck` on every push/PR
