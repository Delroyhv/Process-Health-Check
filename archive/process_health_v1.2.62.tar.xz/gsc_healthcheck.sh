#!/usr/bin/env bash
#
# gsc_healthcheck.sh - End-to-end wrapper for HCP-CS health checks
#
# Usage: ./gsc_healthcheck.sh -c <customer> -s <sr_number> [options]
#

set -euo pipefail
IFS=$'\n\t'

_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load core library
if [[ -r "${_script_dir}/gsc_core.sh" ]]; then
  # shellcheck disable=SC1091
  . "${_script_dir}/gsc_core.sh"
else
  echo "ERROR: gsc_core.sh not found in ${_script_dir}" >&2
  exit 1
fi

# Recommended trap for cleanup and memory wiping
trap gsc_cleanup EXIT

_customer=""
_sr_number=""
_support_log=""
_no_metrics=0
_no_psnap=0
_cleanup_mode=0
_override_confirm=""

usage() {
  cat <<EOF
Usage: $(basename "$0") -c <customer> -s <sr_number> [options]

Mandatory:
  -c, --customer NAME      Customer name
  -s, --sr SR_NUMBER       Service Request number

Options:
  -f, --file PATH          Path to supportLogs_*.tar.xz bundle
  --no-psnap               Skip Prometheus snapshot expansion/startup
  --no-metrics             Run health check without Prometheus metrics
  --cleanup                Cleanup containers and REMOVE the extraction directory
  --override=y             Skip confirmation for cleanup
  -h, --help               Show this help message

Example:
  sudo ./gsc_healthcheck.sh -c ACME -s 01234567 -f supportLogs_2026-01-01.tar.xz
EOF
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -c|--customer) _customer="$2"; shift 2 ;;
      -s|--sr) _sr_number="$2"; shift 2 ;;
      -f|--file) _support_log="$2"; shift 2 ;;
      --no-psnap) _no_psnap=1; _no_metrics=1; shift ;;
      --no-metrics) _no_metrics=1; shift ;;
      --cleanup) _cleanup_mode=1; shift ;;
      --override=y) _override_confirm="y"; shift ;;
      -h|--help) usage; exit 0 ;;
      *) gsc_log_error "Unknown argument: $1"; usage; exit 1 ;;
    esac
  done
  [[ -n "${_customer}" ]] || gsc_die "Customer name (-c) is mandatory."
  [[ -n "${_sr_number}" ]] || gsc_die "SR number (-s) is mandatory."
}

do_cleanup() {
  gsc_log_info "Cleaning up health check artifacts for ${_customer} / ${_sr_number}..."
  
  # Ensure we have sudo access for cleanup
  gsc_prompt_sudo_password

  # 1. Stop Prometheus containers matching this SR/customer
  local _runtime
  _runtime=$(gsc_detect_engine)
  # Pattern matches gsc_prometheus_CUSTOMER_SR_PORT
  gsc_container_cleanup "${_runtime}" "^gsc_prometheus_${_customer}_${_sr_number}_" "${_override_confirm}" "0"

  # 2. Locate and remove the directory
  local _target_dir=""
  local _sr_base_dir=""
  if [[ -d "${_sr_number}" ]]; then
    _sr_base_dir="${_sr_number}"
  elif [[ -d "/ci/${_sr_number}" ]]; then
    _sr_base_dir="/ci/${_sr_number}"
  fi

  if [[ -n "${_sr_base_dir}" ]]; then
    _target_dir=$(find "${_sr_base_dir}" -maxdepth 1 -type d -name "20[0-9][0-9]-[0-9][0-9]-[0-9][0-9]_*" | sort -r | head -n 1)
  fi

  if [[ -n "${_target_dir}" && -d "${_target_dir}" ]]; then
    if [[ "${_override_confirm}" != "y" ]]; then
        read -p "REALLY remove directory ${_target_dir}? (y/N): " _ans
        [[ "${_ans,,}" != "y" ]] && gsc_die "Directory removal cancelled."
    fi
    gsc_log_info "Removing directory (with gsc_sudo): ${_target_dir}"
    gsc_sudo rm -rf "${_target_dir}"
    gsc_log_success "Cleanup complete."
  else
    gsc_log_warn "Could not find extraction directory to remove."
  fi
}

# Steps 4+5 for one extracted support log directory.
# Called inside a subshell already cd'd into the target dir.
# $1 = customer name to use for Prometheus (may have a _NNNN suffix)
_run_dir_checks() {
  local _run_customer="$1"

  # Step 4: Prometheus Setup
  local -a _snapshots=()
  local _snapshot _prom_customer
  while IFS= read -r _snapshot; do [[ -n "${_snapshot}" ]] && _snapshots+=("${_snapshot}"); done < <(ls psnap_*.tar.xz 2>/dev/null || true)

  if [[ "${_no_psnap}" -eq 1 || "${_no_metrics}" -eq 1 ]]; then
    gsc_log_info "Step 4: Skipping Prometheus setup (--no-psnap or --no-metrics set)."
  elif [[ "${#_snapshots[@]}" -gt 0 ]]; then
    for _snapshot in "${_snapshots[@]}"; do
      _prom_customer="${_run_customer}"
      if [[ "${#_snapshots[@]}" -gt 1 ]]; then
        _prom_customer=$(printf '%s_%04d' "${_run_customer}" "$(( RANDOM % 9000 + 1000 ))")
      fi
      gsc_log_info "Step 4: Running gsc_prometheus.sh with gsc_sudo for snapshot: ${_snapshot} (customer: ${_prom_customer})"
      gsc_sudo "${_script_dir}/gsc_prometheus.sh" -c "${_prom_customer}" -s "${_sr_number}" -f "${_snapshot}" -b .
    done
  else
    if [[ -f "healthcheck.conf" ]]; then
      gsc_log_info "Step 4: Prometheus already set up (healthcheck.conf exists)."
    else
      gsc_log_warn "Step 4: No snapshot found and no healthcheck.conf; disabling metrics."
      _no_metrics=1
    fi
  fi

  # Step 5: Run Health Check
  gsc_log_info "Step 5: Running health check suite..."
  local _chk_args=()
  [[ -f "healthcheck.conf" ]] && _chk_args+=("-f" "healthcheck.conf")
  [[ "${_no_metrics}" -eq 1 ]] && _chk_args+=("--no-metrics")

  "${_script_dir}/runchk.sh" "${_chk_args[@]}"
}

main() {
  parse_args "$@"

  if [[ "${_cleanup_mode}" -eq 1 ]]; then
    do_cleanup
    exit 0
  fi

  # Prompt for sudo password once at the start if needed
  gsc_prompt_sudo_password

  gsc_log_info "Step 1: Expanding support bundle..."
  local _expand_cmd=("${_script_dir}/expand_hcpcs_support.sh")
  [[ -n "${_support_log}" ]] && _expand_cmd+=("-f" "${_support_log}")

  local _tmp_dir _tmp_out
  _tmp_dir=$(mktemp -d)
  gsc_add_tmp_dir "${_tmp_dir}"              # will be cleaned up by gsc_cleanup
  _tmp_out="${_tmp_dir}/expand.out"

  ( "${_expand_cmd[@]}" ) 2>&1 | tee "${_tmp_out}" || gsc_log_info "Expansion step finished."

  gsc_log_info "Step 2: Locating health check directories for SR ${_sr_number}..."
  local _sr_base_dir=""
  if [[ -d "${_sr_number}" ]]; then
    _sr_base_dir="${_sr_number}"
  elif [[ -d "/ci/${_sr_number}" ]]; then
    _sr_base_dir="/ci/${_sr_number}"
  else
    _sr_base_dir="."
  fi

  local -a _target_dirs=()
  while IFS= read -r _d; do
    [[ -n "${_d}" ]] && _target_dirs+=("${_d}")
  done < <(find "${_sr_base_dir}" -maxdepth 1 -type d -name "20[0-9][0-9]-[0-9][0-9]-[0-9][0-9]_*" | sort)

  [[ "${#_target_dirs[@]}" -gt 0 ]] || gsc_die "Could not find any health check directories for SR ${_sr_number}."

  local _multi_log=0
  [[ "${#_target_dirs[@]}" -gt 1 ]] && _multi_log=1

  if [[ "${_multi_log}" -eq 1 ]]; then
    gsc_log_info "Found ${#_target_dirs[@]} support log directories — each will use a unique customer name suffix."
  fi

  local _target_dir _run_customer
  for _target_dir in "${_target_dirs[@]}"; do
    _run_customer="${_customer}"
    if [[ "${_multi_log}" -eq 1 ]]; then
      _run_customer=$(printf '%s_%04d' "${_customer}" "$(( RANDOM % 9000 + 1000 ))")
    fi
    gsc_log_info "Step 3: Entering directory: ${_target_dir} (customer: ${_run_customer})"
    (
      cd "${_target_dir}"
      _run_dir_checks "${_run_customer}"
    )
  done

  gsc_log_success "Health check complete for ${_customer} / ${_sr_number}."
}

main "$@"
